const crypto = require('crypto');
const G = require('../shared/game.js');
const rooms = new Map();
const T = { COUNTDOWN: 3000, GRACE: 1500, REVIEW: 45000, RESULT: 8000 }; // mutable so tests can shorten them
const MAX_PLAYERS = 10, MAX_ROOMS = 500, SEP = '\u0001';
const ALLOWED = { LOBBY: ['COUNTDOWN'], COUNTDOWN: ['PLAYING'], PLAYING: ['ANSWER_REVIEW', 'ROUND_RESULTS', 'GAME_RESULTS'],
  ANSWER_REVIEW: ['ROUND_RESULTS', 'GAME_RESULTS'], ROUND_RESULTS: ['COUNTDOWN'], GAME_RESULTS: ['COUNTDOWN'] };
const canGo = (a, b) => (ALLOWED[a] || []).includes(b);
const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const newCode = () => { let c; do { c = Array.from({ length: 5 }, () => A[Math.random() * A.length | 0]).join(''); } while (rooms.has(c)); return c; };
const pid = () => Math.random().toString(36).slice(2, 8);
const hash = t => crypto.createHash('sha256').update(t).digest();
const tokOk = (p, t) => crypto.timingSafeEqual(p.tokHash, hash(t));
const plist = r => [...r.players.values()];
const online = r => plist(r).filter(p => p.online);
const err = (c, text) => c.send({ t: 'error', text });
const nick = n => G.clean(n).slice(0, 16);

/* ---- message validation ---- */
const hex = (x, re) => typeof x === 'string' && re.test(x);
const str = (x, max, min = 0) => typeof x === 'string' && x.length >= min && x.length <= max;
const obj = x => x && typeof x === 'object' && !Array.isArray(x);
const letterOk = m => m.letter == null || (typeof m.letter === 'string' && G.LETTERS.includes(m.letter));
const SCHEMA = {
  create: m => hex(m.sid, /^[a-f0-9]{16,64}$/) && str(m.name, 40, 1),
  join: m => hex(m.sid, /^[a-f0-9]{16,64}$/) && str(m.name, 40, 1) && str(m.code, 8, 1) && (m.tok === undefined || hex(m.tok, /^[a-f0-9]{32}$/)),
  ready: m => typeof m.ready === 'boolean',
  settings: m => obj(m.settings),
  start: letterOk, next: letterOk,
  submit: m => obj(m.answers) && Object.keys(m.answers).length <= 30 && Object.values(m.answers).every(v => typeof v === 'string' && v.length <= 200),
  vote: m => str(m.cat, 20, 1) && str(m.target, 16, 1) && (m.v === 'valid' || m.v === 'invalid'),
  reviewDone: () => true, leave: () => true
};
function check(m) {
  if (!obj(m) || typeof m.t !== 'string') return 'پیام نامعتبر است';
  if (!Object.prototype.hasOwnProperty.call(SCHEMA, m.t)) return 'پیام ناشناخته';
  return SCHEMA[m.t](m) ? null : 'پیام نامعتبر است';
}

/* ---- views ---- */
function tally(r, it, me) {
  const vm = r.votes.get(it.p + SEP + it.c); let v = 0, i = 0;
  if (vm) vm.forEach(x => x === 'valid' ? v++ : i++);
  return { v, i, m: (vm && vm.get(me)) || null };
}
function view(r, p) {
  return { code: r.code, me: p.pid, host: r.players.get(r.host).pid, state: r.state, settings: r.settings, round: r.round, letter: r.letter,
    endsAt: r.endsAt, span: r.span, now: Date.now(), results: r.results,
    review: r.state === 'ANSWER_REVIEW' ? { cats: r.settings.cats, items: r.rows.map(it => Object.assign({ c: it.c, p: it.p, a: it.a, st: it.st, votable: it.st === 'ok' }, tally(r, it, p.pid))) } : null,
    players: plist(r).map(x => ({ pid: x.pid, name: x.name, ready: x.ready, online: x.online, score: x.score, done: r.done.has(x.pid) })) };
}
function push(r) { for (const p of plist(r)) if (p.online && p.conn) p.conn.send({ t: 'state', v: view(r, p) }); }
function notice(r, text) { for (const p of plist(r)) if (p.online && p.conn) p.conn.send({ t: 'notice', text }); }

/* ---- state machine (every transition goes through go) ---- */
function go(r, s, ms, fn, timerMs) {
  if (!canGo(r.state, s)) throw new Error('invalid transition ' + r.state + '>' + s);
  clearTimeout(r.timer);
  r.state = s; r.span = ms || 0; r.endsAt = ms ? Date.now() + ms : 0;
  if (fn) r.timer = setTimeout(() => { try { fn(); } catch (e) { console.error(e); } }, timerMs == null ? ms : timerMs);
  push(r);
}
function begin(r, letter, auto) {
  if (!canGo(r.state, 'COUNTDOWN')) return;
  const mode = auto && r.settings.letterMode === 'manual' ? 'balanced' : r.settings.letterMode;
  r.round++; r.letter = G.pickLetter(r.used, letter, mode); r.used.push(r.letter);
  r.answers = {}; r.done = new Set(); r.results = null; r.items = []; r.rows = []; r.votes = new Map();
  go(r, 'COUNTDOWN', T.COUNTDOWN, () => play(r));
}
function play(r) {
  if (r.state !== 'COUNTDOWN') return;
  const ms = r.settings.duration * 1000;
  go(r, 'PLAYING', ms, () => closeRound(r), ms + T.GRACE);
}
function closeRound(r) {
  if (r.state !== 'PLAYING') return;
  if (r.settings.review && online(r).length >= 2) {
    const rows = [];
    for (const p of plist(r)) { const a = r.answers[p.pid] || {};
      for (const c of r.settings.cats) rows.push({ c, p: p.pid, a: G.clean(a[c]).slice(0, 40), st: G.validate(a[c], r.letter, c) }); }
    const items = rows.filter(x => x.st === 'ok'); // only answers that pass automatic validation can be voted on
    if (items.length) { r.rows = rows; r.items = items; r.votes = new Map(); r.done = new Set(); return go(r, 'ANSWER_REVIEW', T.REVIEW, () => settle(r)); }
  }
  settle(r);
}
function settle(r) {
  if (r.state !== 'PLAYING' && r.state !== 'ANSWER_REVIEW') return;
  const rej = {};
  r.votes.forEach((vm, key) => { let v = 0, i = 0; vm.forEach(x => x === 'valid' ? v++ : i++); if (i > v) rej[key] = true; });
  const all = {}; for (const p of plist(r)) all[p.pid] = r.answers[p.pid] || {};
  const per = G.scoreRound(all, r.settings.cats, r.letter, rej);
  for (const p of plist(r)) p.score += per[p.pid].total;
  r.results = { round: r.round, letter: r.letter, cats: r.settings.cats, per }; r.items = []; r.rows = [];
  const rr = r.round;
  if (rr >= r.settings.rounds) return go(r, 'GAME_RESULTS', 0);
  if (r.settings.autoNext) return go(r, 'ROUND_RESULTS', T.RESULT, () => { if (r.state === 'ROUND_RESULTS' && r.round === rr) begin(r, null, true); });
  go(r, 'ROUND_RESULTS', 0);
}
function progress(r) {
  const all = online(r).every(p => r.done.has(p.pid));
  if (r.state === 'PLAYING' && all) closeRound(r);
  else if (r.state === 'ANSWER_REVIEW' && all) settle(r);
  else push(r);
}

/* ---- players ---- */
function reassign(r) {
  const cur = r.players.get(r.host);
  if (cur && cur.online) return;
  const n = online(r)[0];
  if (n) { r.host = n.sid; n.ready = true; notice(r, `${n.name} میزبان جدید اتاق شد`); }
}
function drop(r, sid) {
  r.players.delete(sid);
  if (!online(r).length) { clearTimeout(r.timer); clearTimeout(r.gc); rooms.delete(r.code); return; }
  reassign(r); progress(r);
}
function attach(r, c, p) {
  if (p.conn && p.conn !== c) { try { p.conn.send({ t: 'error', text: 'نشست در دستگاه دیگری باز شد' }); p.conn.close(); } catch (e) {} }
  p.conn = c; p.online = true; c.sid = p.sid; c.code = r.code; clearTimeout(r.gc); clearTimeout(p.gone);
}
function addPlayer(room, c, sid, name, ready) {
  const tok = crypto.randomBytes(16).toString('hex');
  const p = { sid, pid: pid(), name, ready, online: true, score: 0, conn: null, tokHash: hash(tok) };
  room.players.set(sid, p); attach(room, c, p); c.send({ t: 'joined', tok }); reassign(room); push(room);
}
function roomOf(c) { const r = rooms.get(c.code); return r && r.players.has(c.sid) ? r : null; }

function handle(c, m) {
  const bad = check(m); if (bad) return err(c, bad);
  const r = roomOf(c), me = r && r.players.get(c.sid);
  if (m.t === 'create' || m.t === 'join') {
    if (r) return err(c, 'شما در یک اتاق هستید');
    const name = nick(m.name);
    if (!name) return err(c, 'نام مستعار را وارد کنید');
    if (m.t === 'create') {
      if (rooms.size >= MAX_ROOMS) return err(c, 'سرور شلوغ است؛ بعداً دوباره تلاش کنید');
      const room = { code: newCode(), host: m.sid, players: new Map(), settings: G.defaultSettings(), state: 'LOBBY', round: 0, letter: null, used: [],
        endsAt: 0, span: 0, answers: {}, done: new Set(), results: null, items: [], rows: [], votes: new Map() };
      rooms.set(room.code, room); return addPlayer(room, c, m.sid, name, true);
    }
    const room = rooms.get(m.code.toUpperCase());
    if (!room) return err(c, 'اتاقی با این کد پیدا نشد');
    const old = room.players.get(m.sid);
    if (old) { // reconnect: needs the secret token issued by the server
      if (!m.tok || !tokOk(old, m.tok)) return err(c, 'نشست معتبر نیست');
      attach(room, c, old); return push(room);
    }
    if (room.state !== 'LOBBY') return err(c, 'بازی قبلاً شروع شده است');
    if (room.players.size >= MAX_PLAYERS) return err(c, 'اتاق پر است');
    return addPlayer(room, c, m.sid, name, false);
  }
  if (!r) return err(c, 'اتاق پیدا نشد');
  const host = r.host === c.sid;
  switch (m.t) {
    case 'ready':
      if (r.state !== 'LOBBY') return err(c, 'اکنون ممکن نیست');
      me.ready = m.ready; return push(r);
    case 'settings': {
      if (!host) return err(c, 'فقط میزبان می‌تواند تنظیمات را تغییر دهد');
      if (r.state !== 'LOBBY') return err(c, 'بازی شروع شده است');
      const s = G.sanitizeSettings(m.settings);
      if (!s) return err(c, 'تنظیمات نامعتبر است');
      r.settings = s; return push(r);
    }
    case 'start': case 'next': {
      if (!host) return err(c, 'فقط میزبان می‌تواند این کار را انجام دهد');
      const okState = m.t === 'start' ? (r.state === 'LOBBY' || r.state === 'GAME_RESULTS') : r.state === 'ROUND_RESULTS';
      if (!okState) return err(c, 'اکنون ممکن نیست');
      if (m.t === 'start' && online(r).some(p => !p.ready)) return err(c, 'همه بازیکنان باید آماده باشند');
      if (r.settings.letterMode === 'manual' && !m.letter) return err(c, 'در حالت دستی باید یک حرف انتخاب کنید');
      if (r.state === 'GAME_RESULTS') { r.round = 0; r.used = []; r.results = null; plist(r).forEach(p => { p.score = 0; }); }
      return begin(r, m.letter);
    }
    case 'submit': {
      if (r.state !== 'PLAYING') return err(c, 'زمان ارسال پاسخ تمام شده است');
      if (r.done.has(me.pid)) return;
      const a = {}; for (const k of r.settings.cats) a[k] = G.clean(m.answers[k]).slice(0, 40);
      r.answers[me.pid] = a; r.done.add(me.pid); return progress(r);
    }
    case 'vote': {
      if (r.state !== 'ANSWER_REVIEW') return err(c, 'اکنون زمان رأی‌گیری نیست');
      if (r.done.has(me.pid)) return err(c, 'رأی‌گیری شما پایان یافته است');
      if (m.target === me.pid) return err(c, 'نمی‌توانید به پاسخ خودتان رأی بدهید');
      const key = m.target + SEP + m.cat;
      if (!r.items.some(it => it.p + SEP + it.c === key)) return err(c, 'این پاسخ قابل رأی‌دادن نیست');
      const vm = r.votes.get(key) || new Map();
      if (vm.has(me.pid)) return err(c, 'قبلاً به این پاسخ رأی داده‌اید');
      vm.set(me.pid, m.v); r.votes.set(key, vm); return push(r);
    }
    case 'reviewDone':
      if (r.state !== 'ANSWER_REVIEW') return err(c, 'اکنون ممکن نیست');
      r.done.add(me.pid); return progress(r);
    case 'leave': c.send({ t: 'left' }); c.code = null; return drop(r, me.sid);
  }
}
function disconnect(c) {
  const r = roomOf(c); if (!r) return;
  const p = r.players.get(c.sid);
  if (p.conn !== c) return; // replaced by a newer connection
  p.online = false; p.conn = null; reassign(r);
  if (!online(r).length) { r.gc = setTimeout(() => { clearTimeout(r.timer); rooms.delete(r.code); }, 120000); return; }
  if (r.state === 'LOBBY') p.gone = setTimeout(() => { if (!p.online && r.players.has(p.sid)) drop(r, p.sid); }, 30000);
  progress(r);
}
module.exports = { handle, disconnect, rooms, T, ALLOWED, canGo, check };
