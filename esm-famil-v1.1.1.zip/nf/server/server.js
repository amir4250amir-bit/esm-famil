const http = require('http'), fs = require('fs'), path = require('path');
const { WebSocketServer } = require('ws');
const R = require('./rooms.js');
const ROOT = path.join(__dirname, '..'), PORT = process.env.PORT || 3000;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8' };
const server = http.createServer((req, res) => {
  let u = req.url.split('?')[0]; if (u === '/') u = '/client/index.html';
  if (!/^\/(client|shared)\/[\w-][\w.-]*$/.test(u)) { res.writeHead(404); return res.end('Not found'); }
  fs.readFile(path.join(ROOT, u), (e, d) => {
    if (e) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(u)] || 'text/plain' }); res.end(d);
  });
});
const wss = new WebSocketServer({ server, maxPayload: 4096 });
wss.on('connection', ws => {
  const c = { send: o => { if (ws.readyState === 1) ws.send(JSON.stringify(o)); }, close: () => ws.close(), sid: null, code: null };
  let n = 0, t0 = Date.now(); ws.alive = true;
  ws.on('pong', () => { ws.alive = true; });
  ws.on('message', raw => {
    if (Date.now() - t0 > 1000) { t0 = Date.now(); n = 0; }
    if (++n > 20) return;
    let m; try { m = JSON.parse(raw.toString()); } catch (e) { return c.send({ t: 'error', text: 'پیام نامعتبر است' }); }
    if (!m || typeof m !== 'object' || typeof m.t !== 'string') return c.send({ t: 'error', text: 'پیام نامعتبر است' });
    try { R.handle(c, m); } catch (e) { console.error(e); c.send({ t: 'error', text: 'خطای داخلی سرور' }); }
  });
  ws.on('close', () => { try { R.disconnect(c); } catch (e) { console.error(e); } });
  ws.on('error', () => {});
});
setInterval(() => wss.clients.forEach(ws => { if (!ws.alive) return ws.terminate(); ws.alive = false; ws.ping(); }), 30000);
server.listen(PORT, () => console.log('Server on port ' + PORT));
