const assert = require('assert'), G = require('../shared/game.js'), R = require('../server/rooms.js');
R.T.COUNTDOWN = 15; R.T.GRACE = 10; R.T.REVIEW = 60; R.T.RESULT = 40;
const sleep = ms => new Promise(r => setTimeout(r, ms));
let n = 0; const sid = () => (++n).toString(16).padStart(32, 'a');
function conn() {
  const c = { sent: [], closed: false, send(o) { this.sent.push(o); }, close() { this.closed = true; } };
  c.view = () => [...c.sent].reverse().find(x => x.t === 'state').v;
  c.errs = () => c.sent.filter(x => x.t === 'error').length;
  c.tok = () => c.sent.find(x => x.t === 'joined').tok;
  return c;
}
const bad = (c, m) => { const k = c.errs(); R.handle(c, m); assert.strictEqual(c.errs(), k + 1, 'expected error for ' + JSON.stringify(m)); };
const good = (c, m) => { const k = c.errs(); R.handle(c, m); assert.strictEqual(c.errs(), k, 'unexpected error for ' + JSON.stringify(m)); };
function mk(k) {
  const h = conn(); R.handle(h, { t: 'create', sid: sid(), name: 'میزبان' }); const code = h.view().code, cs = [h];
  for (let i = 1; i < k; i++) { const c = conn(); R.handle(c, { t: 'join', sid: sid(), name: 'p' + i, code }); R.handle(c, { t: 'ready', ready: true }); cs.push(c); }
  return { cs, code, room: R.rooms.get(code), h };
}
const cfg = (x, o) => good(x.h, { t: 'settings', settings: Object.assign({}, x.h.view().settings, o) });
async function play(x, letter) { good(x.h, { t: 'start', letter }); assert.strictEqual(x.h.view().state, 'COUNTDOWN'); await sleep(40); assert.strictEqual(x.h.view().state, 'PLAYING'); }
const names = x => Object.fromEntries(x.h.view().players.map(p => [p.name, p.score]));
const tests = [];
const test = (name, fn) => tests.push([name, fn]);

test('normalize / validate / score', () => {
  assert.strictEqual(G.norm('عليٌ  ك'), 'علی ک');
  assert.strictEqual(G.validate('آب', 'ا'), 'ok'); assert.strictEqual(G.validate('سیب', 'ا'), 'invalid'); assert.strictEqual(G.validate(' ', 'ا'), 'empty');
  const sc = G.scoreRound({ a: { اسم: 'اکبر', شهر: 'اهواز' }, b: { اسم: 'اکبر', شهر: 'اراک' } }, ['اسم', 'شهر'], 'ا');
  assert.strictEqual(sc.a.total, 15);
  const rj = G.scoreRound({ a: { اسم: 'اکبر' }, b: { اسم: 'اکبر' } }, ['اسم'], 'ا', { ['a\u0001اسم']: true });
  assert.strictEqual(rj.a.total, 0); assert.strictEqual(rj.b.total, 10); assert.ok(rj.a.cats['اسم'].rej);
});
test('custom duration 15..300 and settings validation', () => {
  const base = G.defaultSettings();
  for (const d of [15, 16, 123, 300]) assert.ok(G.sanitizeSettings({ ...base, duration: d }), 'dur ' + d);
  for (const d of [14, 301, -5, 0, NaN, Infinity, '60', null, [60]]) assert.strictEqual(G.sanitizeSettings({ ...base, duration: d }), null, 'dur ' + d);
  assert.strictEqual(G.sanitizeSettings({ ...base, cats: [] }), null);
  assert.strictEqual(G.sanitizeSettings({ ...base, letterMode: 'zzz' }).letterMode, 'balanced');
  const x = mk(2); bad(x.h, { t: 'settings', settings: { ...base, duration: 14 } });
  cfg(x, { duration: 17 }); assert.strictEqual(x.h.view().settings.duration, 17);
  bad(x.cs[1], { t: 'settings', settings: base });
  R.handle(x.cs[1], { t: 'leave' }); R.handle(x.h, { t: 'leave' });
});
test('letter modes', () => {
  const rest = G.LETTERS.filter(l => l !== 'ی');
  for (let i = 0; i < 60; i++) assert.strictEqual(G.pickLetter(rest, null, 'balanced'), 'ی');
  const seen = new Set(); for (let i = 0; i < 500; i++) seen.add(G.pickLetter(rest, null, 'random'));
  assert.ok(seen.size > 1); assert.strictEqual(G.pickLetter(rest, 'پ', 'random'), 'پ');
  assert.ok(G.LETTERS.includes(G.pickLetter(G.LETTERS, null, 'balanced')));
  const x = mk(1); cfg(x, { letterMode: 'manual' });
  bad(x.h, { t: 'start' }); assert.strictEqual(x.h.view().state, 'LOBBY');
  good(x.h, { t: 'start', letter: 'پ' }); assert.strictEqual(x.h.view().letter, 'پ');
  R.handle(x.h, { t: 'leave' });
});
test('state transition table', () => {
  assert.deepStrictEqual(Object.keys(R.ALLOWED), ['LOBBY', 'COUNTDOWN', 'PLAYING', 'ANSWER_REVIEW', 'ROUND_RESULTS', 'GAME_RESULTS']);
  assert.ok(R.canGo('PLAYING', 'ANSWER_REVIEW') && R.canGo('ANSWER_REVIEW', 'ROUND_RESULTS'));
  assert.ok(!R.canGo('LOBBY', 'PLAYING') && !R.canGo('ROUND_RESULTS', 'PLAYING') && !R.canGo('GAME_RESULTS', 'ROUND_RESULTS'));
  const x = mk(1); bad(x.h, { t: 'next' }); bad(x.h, { t: 'submit', answers: {} }); bad(x.h, { t: 'vote', cat: 'اسم', target: 'x', v: 'valid' }); bad(x.h, { t: 'reviewDone' });
  good(x.h, { t: 'start', letter: 'ا' }); bad(x.h, { t: 'start' }); bad(x.h, { t: 'settings', settings: x.h.view().settings }); bad(x.h, { t: 'ready', ready: false });
  R.handle(x.h, { t: 'leave' });
});
test('answer review, voting, self vote, duplicate vote, scoring after vote', async () => {
  const x = mk(3), [A, B, C] = x.cs; cfg(x, { review: true, duration: 60 }); await play(x, 'ا');
  good(A, { t: 'submit', answers: { اسم: 'اکبر', شهر: 'اراک' } }); good(B, { t: 'submit', answers: { اسم: 'اکبر', شهر: 'اهواز' } });
  assert.strictEqual(A.view().state, 'PLAYING'); good(C, { t: 'submit', answers: { اسم: 'علی' } });
  assert.strictEqual(A.view().state, 'ANSWER_REVIEW');
  const items = A.view().review.items; assert.strictEqual(items.filter(i => i.votable).length, 4); // C's wrong-letter answer is shown but not votable
  const pa = A.view().me, pc = C.view().me;
  bad(A, { t: 'vote', cat: 'اسم', target: pa, v: 'valid' });          // self vote
  bad(B, { t: 'vote', cat: 'اسم', target: pc, v: 'invalid' });        // not a votable item
  bad(B, { t: 'vote', cat: 'اسم', target: 'nobody', v: 'invalid' });  // unknown player
  good(B, { t: 'vote', cat: 'اسم', target: pa, v: 'invalid' }); good(C, { t: 'vote', cat: 'اسم', target: pa, v: 'invalid' });
  bad(C, { t: 'vote', cat: 'اسم', target: pa, v: 'valid' });          // duplicate vote (even a different value)
  const it = B.view().review.items.find(i => i.p === pa && i.c === 'اسم');
  assert.deepStrictEqual([it.v, it.i, it.m], [0, 2, 'invalid']);
  good(A, { t: 'reviewDone' }); bad(A, { t: 'vote', cat: 'شهر', target: B.view().me, v: 'valid' });
  good(B, { t: 'reviewDone' }); assert.strictEqual(A.view().state, 'ANSWER_REVIEW'); good(C, { t: 'reviewDone' });
  assert.strictEqual(A.view().state, 'ROUND_RESULTS');
  assert.deepStrictEqual(names(x), { 'میزبان': 10, p1: 20, p2: 0 });
  assert.ok(A.view().results.per[pa].cats['اسم'].rej);
  bad(B, { t: 'vote', cat: 'اسم', target: pa, v: 'valid' });          // wrong state
  for (const c of x.cs) R.handle(c, { t: 'leave' });
});
test('review timeout and review disabled', async () => {
  let x = mk(2); cfg(x, { review: true }); await play(x, 'ا');
  good(x.cs[0], { t: 'submit', answers: { اسم: 'اکبر' } }); good(x.cs[1], { t: 'submit', answers: { اسم: 'احمد' } });
  assert.strictEqual(x.h.view().state, 'ANSWER_REVIEW'); await sleep(120);
  assert.strictEqual(x.h.view().state, 'ROUND_RESULTS'); assert.deepStrictEqual(names(x), { 'میزبان': 10, p1: 10 });
  x.cs.forEach(c => R.handle(c, { t: 'leave' }));
  x = mk(2); cfg(x, { review: false }); await play(x, 'ا');
  x.cs.forEach(c => good(c, { t: 'submit', answers: { اسم: 'اکبر' } })); assert.strictEqual(x.h.view().state, 'ROUND_RESULTS'); assert.deepStrictEqual(names(x), { 'میزبان': 5, p1: 5 });
  x.cs.forEach(c => R.handle(c, { t: 'leave' }));
});
test('late submission rejected by server deadline', async () => {
  const x = mk(2); cfg(x, { review: false }); x.room.settings.duration = 0.05; await play(x, 'ا');
  await sleep(150); assert.strictEqual(x.h.view().state, 'ROUND_RESULTS'); bad(x.h, { t: 'submit', answers: { اسم: 'اکبر' } });
  x.cs.forEach(c => R.handle(c, { t: 'leave' }));
});
test('automatic next round, game end, rematch', async () => {
  const x = mk(2), [H, B] = x.cs; cfg(x, { review: false, autoNext: true, rounds: 2 }); await play(x, 'ا');
  x.cs.forEach(c => good(c, { t: 'submit', answers: { اسم: 'اکبر' } }));
  assert.strictEqual(H.view().state, 'ROUND_RESULTS'); assert.ok(H.view().endsAt > 0);
  await sleep(90); assert.strictEqual(H.view().round, 2); await sleep(40); assert.strictEqual(H.view().state, 'PLAYING');
  const L2 = H.view().letter; assert.ok(L2); x.cs.forEach(c => good(c, { t: 'submit', answers: { اسم: L2 + 'ابا' } })); // round-2 letter is chosen by the server
  assert.strictEqual(H.view().state, 'GAME_RESULTS'); await sleep(120); assert.strictEqual(H.view().state, 'GAME_RESULTS');
  assert.deepStrictEqual(names(x), { 'میزبان': 10, p1: 10 });
  bad(B, { t: 'start' }); good(H, { t: 'start' });
  assert.strictEqual(H.view().state, 'COUNTDOWN'); assert.strictEqual(H.view().round, 1); assert.deepStrictEqual(names(x), { 'میزبان': 0, p1: 0 });
  x.cs.forEach(c => R.handle(c, { t: 'leave' }));
});
test('manual next needs host and manual letter', async () => {
  const x = mk(2); cfg(x, { review: false, autoNext: false, letterMode: 'manual' }); good(x.h, { t: 'start', letter: 'ب' }); await sleep(40);
  x.cs.forEach(c => good(c, { t: 'submit', answers: {} })); assert.strictEqual(x.h.view().state, 'ROUND_RESULTS');
  bad(x.cs[1], { t: 'next', letter: 'ا' }); bad(x.h, { t: 'next' }); good(x.h, { t: 'next', letter: 'ج' }); assert.strictEqual(x.h.view().letter, 'ج');
  x.cs.forEach(c => R.handle(c, { t: 'leave' }));
});
test('reconnect with token mid-game, hijack protection, duplicate connection', async () => {
  const x = mk(2), [H, B] = x.cs; cfg(x, { review: false }); await play(x, 'ا');
  const spy = conn(); bad(spy, { t: 'join', sid: B.sid, name: 'x', code: x.code });                   // knows sid, no token
  bad(spy, { t: 'join', sid: B.sid, name: 'x', code: x.code, tok: 'f'.repeat(32) });                   // wrong token
  assert.ok(!B.closed && H.view().players.find(p => p.name === 'p1').online);
  const pidB = B.view().me; R.disconnect(B); assert.ok(!H.view().players.find(p => p.name === 'p1').online);
  const B2 = conn(); good(B2, { t: 'join', sid: B.sid, name: 'p1', code: x.code, tok: B.tok() });
  const v = B2.view(); assert.strictEqual(v.me, pidB); assert.strictEqual(v.state, 'PLAYING'); assert.strictEqual(v.letter, 'ا'); assert.ok(v.endsAt > Date.now() - 50);
  const B3 = conn(); good(B3, { t: 'join', sid: B.sid, name: 'p1', code: x.code, tok: B.tok() });   // duplicate connection
  assert.ok(B2.closed && B2.errs() === 1); R.disconnect(B2);
  assert.ok(H.view().players.find(p => p.name === 'p1').online);
  good(B3, { t: 'submit', answers: { اسم: 'اکبر' } }); good(B3, { t: 'submit', answers: { اسم: 'اکبر' } }); // duplicate submit ignored
  good(H, { t: 'submit', answers: {} }); assert.strictEqual(H.view().state, 'ROUND_RESULTS');
  x.cs.concat([B3]).forEach(c => R.handle(c, { t: 'leave' }));
});
test('invalid websocket messages', () => {
  const c = conn(), big = 'x'.repeat(300);
  for (const m of [null, [], 'str', 5, {}, { t: 5 }, { t: 'nope' }, { t: 'constructor' }, { t: 'create' }, { t: 'create', sid: 'zz', name: 'a' },
    { t: 'create', sid: 12345678901234567890, name: 'a' }, { t: 'create', sid: sid(), name: '' }, { t: 'join', sid: sid(), name: 'a' },
    { t: 'join', sid: sid(), name: 'a', code: 'AAAAA', tok: 'bad' }, { t: 'ready', ready: 'yes' }, { t: 'settings', settings: 'x' }, { t: 'start', letter: 'x' },
    { t: 'submit', answers: [] }, { t: 'submit', answers: { اسم: big } }, { t: 'vote', cat: 'a', target: 'b', v: 'maybe' }]) bad(c, m);
  bad(c, { t: 'join', sid: sid(), name: 'a', code: 'ZZZZZ' }); bad(c, { t: 'ready', ready: true }); bad(c, { t: 'leave' });
  const x = mk(2); x.cs.forEach(k => good(k, { t: 'ready', ready: true }));
  good(x.h, { t: 'start', letter: 'ا' });
  const late = conn(); bad(late, { t: 'join', sid: sid(), name: 'late', code: x.code }); // game already started
  bad(x.cs[1], { t: 'settings', settings: G.defaultSettings() });
  x.cs.forEach(k => R.handle(k, { t: 'leave' }));
});
test('host transfer, disconnect during phases, last player leaving', async () => {
  const x = mk(3), [H, B, C] = x.cs; cfg(x, { review: false });
  R.disconnect(H); assert.strictEqual(B.view().host, B.view().me);
  assert.ok(B.sent.some(m => m.t === 'notice' && m.text.includes('میزبان جدید')));
  good(B, { t: 'settings', settings: { ...B.view().settings, rounds: 2 } }); bad(C, { t: 'settings', settings: B.view().settings });
  good(B, { t: 'start', letter: 'ا' }); await sleep(40);
  good(B, { t: 'submit', answers: {} }); R.disconnect(C); assert.strictEqual(B.view().state, 'ROUND_RESULTS'); // offline player does not block the round
  R.handle(B, { t: 'leave' }); assert.strictEqual(R.rooms.get(x.code), undefined); // nobody online -> room removed
  R.disconnect(B);
});
test('manual letter mode forces autoNext off, and never auto-advances', async () => {
  assert.strictEqual(G.sanitizeSettings({ ...G.defaultSettings(), letterMode: 'manual', autoNext: true }).autoNext, false);
  assert.strictEqual(G.sanitizeSettings({ ...G.defaultSettings(), letterMode: 'random', autoNext: true }).autoNext, true);
  const x = mk(2); cfg(x, { review: false, autoNext: true, letterMode: 'manual', rounds: 3 });
  assert.strictEqual(x.h.view().settings.autoNext, false); assert.strictEqual(x.h.view().settings.letterMode, 'manual');
  cfg(x, { autoNext: true, letterMode: 'balanced' }); assert.strictEqual(x.h.view().settings.autoNext, true); // allowed again outside manual
  cfg(x, { autoNext: true, letterMode: 'manual' }); assert.strictEqual(x.h.view().settings.autoNext, false);
  bad(x.h, { t: 'start' }); good(x.h, { t: 'start', letter: 'ب' }); await sleep(40);
  x.cs.forEach(c => good(c, { t: 'submit', answers: {} })); const v = x.h.view();
  assert.strictEqual(v.state, 'ROUND_RESULTS'); assert.strictEqual(v.endsAt, 0);
  await sleep(R.T.RESULT * 4); assert.strictEqual(x.h.view().state, 'ROUND_RESULTS'); assert.strictEqual(x.h.view().round, 1); // no host letter -> no next round
  good(x.h, { t: 'next', letter: 'ت' }); assert.strictEqual(x.h.view().round, 2); assert.strictEqual(x.h.view().letter, 'ت');
  x.cs.forEach(c => R.handle(c, { t: 'leave' }));
});
test('ANSWER_REVIEW shows every answer; only valid answers are votable', async () => {
  const x = mk(3), [A, B, C] = x.cs; cfg(x, { review: true, duration: 60 }); await play(x, 'ا');
  good(A, { t: 'submit', answers: { اسم: 'اکبر' } }); good(B, { t: 'submit', answers: { اسم: 'سیب' } }); good(C, { t: 'submit', answers: {} });
  assert.strictEqual(A.view().state, 'ANSWER_REVIEW');
  const cats = A.view().settings.cats, pa = A.view().me, pb = B.view().me, pc = C.view().me;
  for (const c of x.cs) { const rows = c.view().review.items; assert.strictEqual(rows.length, 3 * cats.length); // nothing lost, same for every viewer
    for (const p of [pa, pb, pc]) for (const k of cats) assert.strictEqual(rows.filter(r => r.p === p && r.c === k).length, 1); }
  const rows = A.view().review.items, get = (p, k) => rows.find(r => r.p === p && r.c === k);
  assert.deepStrictEqual([get(pa, 'اسم').st, get(pa, 'اسم').votable, get(pa, 'اسم').a], ['ok', true, 'اکبر']);
  assert.deepStrictEqual([get(pb, 'اسم').st, get(pb, 'اسم').votable, get(pb, 'اسم').a], ['invalid', false, 'سیب']); // wrong letter: visible, not votable
  assert.deepStrictEqual([get(pc, 'اسم').st, get(pc, 'اسم').votable, get(pc, 'اسم').a], ['empty', false, '']);
  assert.strictEqual(rows.filter(r => r.votable).length, 1);
  bad(A, { t: 'vote', cat: 'اسم', target: pb, v: 'valid' }); bad(A, { t: 'vote', cat: 'اسم', target: pc, v: 'invalid' }); // invalid / empty
  bad(C, { t: 'vote', cat: 'شهر', target: pa, v: 'valid' });                                                          // empty cell
  bad(A, { t: 'vote', cat: 'اسم', target: pa, v: 'valid' });                                                          // own answer
  good(B, { t: 'vote', cat: 'اسم', target: pa, v: 'valid' }); bad(B, { t: 'vote', cat: 'اسم', target: pa, v: 'invalid' }); // duplicate
  const after = B.view().review.items; assert.strictEqual(after.length, 3 * cats.length);
  const mine = after.find(r => r.p === pa && r.c === 'اسم'); assert.deepStrictEqual([mine.v, mine.i, mine.m], [1, 0, 'valid']);
  x.cs.forEach(c => R.handle(c, { t: 'leave' }));
});
(async () => {
  let fail = 0;
  for (const [name, fn] of tests) { try { await fn(); console.log('✓', name); } catch (e) { fail++; console.log('✗', name, '\n  ', e.message.split('\n').slice(0,4).join(' | ') + ' @ ' + (e.stack.split('\n').find(l => l.includes('test.js')) || '')); } }
  console.log(fail ? `${fail} تست شکست خورد` : `همه ${tests.length} تست موفق بودند`); process.exit(fail ? 1 : 0);
})();
