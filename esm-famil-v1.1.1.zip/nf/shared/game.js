(function (root) {
  const LETTERS = 'ابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی'.split('');
  const CATS = ['اسم','فامیل','شهر','کشور','غذا','حیوان','رنگ','شغل','میوه','وسیله','ماشین','گل','ورزش','فیلم','سریال','شخصیت','برند','کتاب','بازی','اعضای بدن'];
  const RULES = { unique: 10, dup: 5 };
  const clean = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const norm = s => clean(String(s == null ? '' : s).normalize('NFKC')
    .replace(/[\u064A\u0649]/g, 'ی').replace(/\u0643/g, 'ک').replace(/[\u0629\u06C0]/g, 'ه')
    .replace(/[\u064B-\u065F\u0670\u0640\u200E\u200F]/g, '').replace(/\u200C/g, ' '));
  const lkey = c => norm(c).replace(/[آأإ]/g, 'ا').charAt(0);
  const validators = []; // plug a Persian dictionary here: fn(answer, letter, cat) => boolean
  function validate(ans, letter, cat) {
    const n = norm(ans);
    if (!n) return 'empty';
    if (n.length > 40 || lkey(n) !== lkey(letter)) return 'invalid';
    return validators.every(v => v(n, letter, cat)) ? 'ok' : 'invalid';
  }
  function scoreRound(ans, cats, letter, rejected) {
    const per = {};
    for (const id in ans) per[id] = { total: 0, cats: {} };
    for (const c of cats) {
      const count = {};
      for (const id in ans) {
        const a = (ans[id] || {})[c] || '';
        let st = validate(a, letter, c);
        const rj = !!(st === 'ok' && rejected && rejected[id + '\u0001' + c]);
        if (rj) st = 'invalid';
        per[id].cats[c] = { a: clean(a).slice(0, 40), st, pts: 0, rej: rj };
        if (st === 'ok') { const k = norm(a); count[k] = (count[k] || 0) + 1; }
      }
      for (const id in ans) {
        const x = per[id].cats[c];
        if (x.st === 'ok') x.pts = count[norm(x.a)] > 1 ? RULES.dup : RULES.unique;
        per[id].total += x.pts;
      }
    }
    return per;
  }
  const LM = ['balanced', 'random', 'manual'];
  const defaultSettings = () => ({ cats: CATS.slice(0, 8), duration: 60, rounds: 3, letterMode: 'balanced', review: true, autoNext: false });
  function pickLetter(used, want, mode) {
    if (want && LETTERS.includes(want)) return want;
    let pool = LETTERS;
    if (mode !== 'random') { pool = LETTERS.filter(l => !(used || []).includes(l)); if (!pool.length) pool = LETTERS; }
    return pool[Math.floor(Math.random() * pool.length)];
  }
  function sanitizeSettings(s) {
    if (!s || typeof s !== 'object') return null;
    const cats = [...new Set((Array.isArray(s.cats) ? s.cats : []).map(c => clean(c).slice(0, 20)).filter(Boolean))].slice(0, 30);
    if (typeof s.duration !== 'number' || typeof s.rounds !== 'number' || !isFinite(s.duration) || !isFinite(s.rounds)) return null;
    const d = Math.round(s.duration), r = Math.round(s.rounds);
    if (!cats.length || !(d >= 15 && d <= 300) || !(r >= 1 && r <= 10)) return null;
    const letterMode = LM.includes(s.letterMode) ? s.letterMode : 'balanced';
    // manual mode: the host must pick every letter, so automatic next round is always off
    return { cats, duration: d, rounds: r, letterMode, review: s.review === undefined ? true : !!s.review, autoNext: letterMode !== 'manual' && !!s.autoNext };
  }
  const api = { LETTERS, CATS, RULES, LM, clean, norm, validate, scoreRound, pickLetter, sanitizeSettings, defaultSettings, validators };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.G = api;
})(typeof self !== 'undefined' ? self : this);
